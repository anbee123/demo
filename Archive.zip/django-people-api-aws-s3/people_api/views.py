from django.shortcuts import render
from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Person
from .serializers import PersonSerializer
from django.shortcuts import get_object_or_404


# Test View for Homepage

def home(request):
  return HttpResponse('<h1> MY HOME PAGE </h1>')


# Structure of Class Based Views

# class /people (People)
#  GET  /people - index
#  POST /people - create

# class /people/:id (PeopleDetail)
#  GET /people/:id - show
#  PUT /people/:id - update
#  DELETE /people/:id - delete


class People(APIView):

  def get(self, request):
    people = Person.objects.all()
    data = PersonSerializer(people, many=True).data
    return Response(data)

  def post(self, request):
    person = PersonSerializer(data=request.data)
    if person.is_valid():
      person.save()
      return Response(person.data, status=status.HTTP_201_CREATED)
    else: 
      return Response(person.errors, status=status.HTTP_400_BAD_REQUEST)


class PeopleDetail(APIView):

  def get(self, request, pk):
    person = get_object_or_404(Person, pk=pk)
    data = PersonSerializer(person).data
    return Response(data)

  def put(self, request, pk):
    person = get_object_or_404(Person, pk=pk)
    updated = PersonSerializer(person, data=request.data, partial=True)
    if updated.is_valid():
      updated.save()
      return Response(updated.data)
    else:
      return Response(updated.errors, status=status.HTTP_400_BAD_REQUEST)

  def delete(self, request, pk):
    person = get_object_or_404(Person, pk=pk)
    person.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)