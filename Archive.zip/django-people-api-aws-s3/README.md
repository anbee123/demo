# Django People API

<img src="https://i.imgur.com/r4VOQOq.jpg">

# Uploading Images to S3 in Django

Starter code for the AWS S3 code along.

| Students will be able to:                           |
| --------------------------------------------------- |
| Use a `.env` file for environment variables/secrets |
| Set up Amazon S3 to hold an app's uploaded images   |
| Use an HTML `<form>` to send a file to the server   |
| Upload a file to S3 from the server                 |

## Set-up

Fork and clone this repo.

<br>

### Create a Database

Create your database from the command line in your project folder:

`createdb "people"`

If you already have a db named "people" drop it and re-create in the psql shell:

`psql`

Then use the **DROP DATABASE** and **CREATE DATABASE** commands.

```shell
laurenperez=# DROP DATABASE people;
laurenperez=# CREATE DATABASE people;
```

Type `ctr + d` to exit shell.

<br>

### Install Packages

Django needs a few packages installed in your virtual env before this repo will run.

Check your `django-env` Pipfile for:

```py
django = "==4.1"
psycopg2-binary = "*"
djangorestframework = "*"
django-cors-headers = "*"
```

If anything is missing install:

`pipenv install djangorestframework django-cors-headers psycopg2-binary`

<br>

### Start Server

Let's make sure all is working so far.

`python3 manage.py runserver`

There will be an error about migrations that looks like this:

```shell
  You have 18 unapplied migration(s). Your project may not work properly until you apply the migrations for app(s): admin, auth, contenttypes, sessions.
  Run 'python manage.py migrate' to apply them.
```

Those errors will go away when you create your migrations.

Navigate to **localhost:8000/people/home**

You should see:

`MY HOME PAGE`

`ctr + c ` to stop your server.

<br>

### Create Migration Files and Migrate Schema to Database

Triple check that your model file(s) contains all the fields you need.

**Make migration** file(s):

`python3 manage.py makemigrations`

**Migrate** those files over to the DB to generate your tables:

`python3 manage.py migrate`

[Django Migration Command Docs](https://docs.djangoproject.com/en/3.0/topics/migrations/#the-commands)

<br>

### Use The Django Shell to seed DB with People

Run this command to open the shell:

`python3 manage.py shell`

Inside the shell make new entries:

```shell
>>>  from people_api.models import Person
>>>  person = Person(name='Leia Organa', title='Princess', image='https://static.tvtropes.org/pmwiki/pub/images/leia_41.jpg')
>>>  person.save()
```

Exit the Django shell with `ctr + d`

[Database API Command Docs](https://docs.djangoproject.com/en/3.1/topics/db/queries/)

<br>

### Start Server and Confirm /people

Let's make sure all is working so far.

`python3 manage.py runserver`

Navigate to **localhost:8000/people/**

You should see the `Django Rest Framework` GUI with your person JSON object.

`ctr + c ` to stop your server.

<br><br>

### Using a `.env` File for "secrets"

<p style="color:red">Don't ever put your Amazon AWS, other API keys, database connection strings, username/passwords, etc. in your source code!</p>

If you do, and push your code to GitHub, it will be discovered within minutes and could result in a major financial liability!

To protect our "secrets", we can use a `.env` file locally like we did last unit.

Processing the `.env` file in our Django app will require the help from a separate package:

`django-environ`

Let's install it:

```
pip3 install django-environ
```

We can now use the `environ` module in `django_people/settings.py`.

Let's add the following code at the top of **settings.py** (below the other imports near the top of the file is fine):

```python
# settings.py
from pathlib import Path

# add code below
import environ

environ.Env()
environ.Env.read_env()
```

Since we're processing the `.env` from the `settings.py` module, we will need to **create the `.env` in the same folder**:

```
touch django_people/.env
```

<br>

🛑 **BEFORE YOU ADD ANYTHING TO THIS `.env` YOU MUST ADD IT TO A `.gitignore`** 🛑

<br>

We're now ready to add `KEY=VALUE` pairs like we did in the previous unit, for example:

```
SECRET_KEY=SOME_VALUE
```

To access the values in a Python app, we will use the `os.environ` dict - similar to how we used Node's `process.env`.

For example:

```python
from django.shortcuts import render, redirect
# Would need this import
import os
...

def some_function(request):
    secret_key = os.environ['SECRET_KEY']
```

We will be adding **Secret Keys**, a **Bucket**, and a **Base URL** to our .env :

```env
AWS_ACCESS_KEY_ID=<paste your Access key ID>
AWS_SECRET_ACCESS_KEY=<paste your Secret access key>
S3_BUCKET=<your bucket name>
S3_BASE_URL=<base url>
```

<br>

# Sign up for an Amazon S3 Account

AWS (Amazon Web Services) is a cloud platform offering a slew of web services such as compute power, database storage, content delivery and more.

You can see all of the services available by clicking here [Amazon AWS](https://aws.amazon.com/).

The specific web service we are going to use to host our uploaded images is the _Simple Storage Service_, better known as **Amazon S3**.

<br><br>

## Set up for an Amazon AWS Account

Before we can use S3, or any Amazon Web Service, we'll need an Amazon AWS account.

**Notice:** Even though AWS has a "free tier" and we will do nothing in SEI that will cost money, **AWS requires a credit card to open an account**. If you don't wish to provide a credit card, you will not be able to complete this lesson and you won't be able to upload images using Amazon Web Services. Unfortunately, alternative services such as Microsoft Azure have the same credit card requirement.

Click the orange "Sign in to the Console" button, then click "Create a new AWS account".

Unfortunately, the signup process is a bit lengthy...

<br>

Select Create an AWS Account:

![s3 signup](./assets/create-account.png)

<br>

Complete form and select **Basic Support Free**:

![s3 signup](./assets/basic-support.png)

<br>

Complete the rest of signup:

![s3 signup](./assets/go-to-console.png)

<br><br>

### Sign in to the AWS Console

After you have signed up, log in to the Console as **Root user**.

Click the **Services** then **All services** drop-down.

The first thing we're going to do is create access keys to access S3 with.

We will be obtaining two keys: An **Access Key ID** and a **Secret Access Key**.

<br><br>

### Create User Group

![s3 signup](./assets/iam.png)

<br>

Now we need to create a group that will have S3 permissions.

Click the "Create group" button.

Enter a "Group name" - `django-s3-assets` is fine. Then scroll way down and select the "AmazonS3FullAccess" checkbox:

![s3 signup](./assets/group-name.png)

<br>

Add User to the new group you created:

![s3 signup](./assets/add-user-to-group.png)

<br>

Select new User:

![s3 signup](./assets/user.png)

<br>

Select the Security Key Tab under the User Summary:

![s3 signup](./assets/creds.png)

<br>

Select create access keys:

![s3 signup](./assets/access-keys.png)

<br>

Select the option for **Local Code**.

Verify that you know that this is a risky thing to do.

![s3 signup](./assets/risk.png)

<br>

#### Copy both access keys to your `.env`

![s3 signup](./assets/keys.png)

<br><br>

### Create Storage

Under **Services** select **Storage** and then **S3**:

![s3 signup](./assets/storage.png)

<br>

Create a bucket:

Buckets are containers for stuff you store in S3.
Typically, you would want to create an S3 bucket for each web application you develop that needs to use S3.

![s3 signup](./assets/create-bucket.png)

<br><br>

### Name your Bucket

Name your bucket `seir-830-perez-django-people`

You'll have to enter a **globally unique** _Bucket name_.

![s3 signup](./assets/bucket-name.png)

For the best performance, always be sure to select the nearest location to where most of your users will be. For this lesson, be sure to select the Region nearest you.

<br>

Unblock public access to your bucket:

![s3 signup](./assets/unblock.png)

<br>

And finally Create!

![s3 signup](./assets/bucket-created.png)

#### Add your bucket name to your .env.

<br><br>

### Add Bucket Policy

We need to make sure that web browsers will be able to download images when using our app.
To do so, we need to specify a "bucket policy" that enables read-only access to a bucket's objects.

Select your bucket and look for the permissions tab:

![s3 signup](./assets/bucket-permissions.png)

<br>

Click Edit Bucket Policy:

![s3 signup](./assets/edit.png)

<br>

Click policy generator from the main edit screen:

![s3 signup](./assets/policy-gen.png)

<br>

Complete the following fields:

Select Type of Policy: `S3 Bucket Policy`

Principal: `*`

Actions: `GetObject`

<br>

![s3 signup](./assets/policy-fields.png)

<br>

Enter your ARN (Amazon Resource Name):

This next one's a bit challenging. In the "Amazon Resources Name (ARN)" input enter this:

`arn:aws:s3:::NAME_OF_BUCKET/*`

but substituting your bucket name.

Mine will look like this: `arn:aws:s3:::seir-830-perez-django-people/*`

![s3 signup](./assets/arn.png)

<br>

Click **Add Statement** and **Generate Policy**.

![s3 signup](./assets/gen-policy.png)

<br>

This will provide you with a snippet to add to your bucket policy page:

![s3 signup](./assets/policy.png)

<br>

Paste this in the statement section of your bucket policy edit page:

![s3 signup](./assets/paste-policy.png)

<br>

You should now see red warnings all around that your bucket is public.

![s3 signup](./assets/policy-warn.png)

<br>

Congrats! You now have an S3 bucket that, using the access keys, an application can upload files of any type to. Also, any browser can download those files by using a URL that we generate.

Now let's get on with the app!

<br>

## Install & Configure Boto3

The official Amazon AWS SDK (Software Development Kit) for Python is a library called [Boto3](https://boto3.amazonaws.com/v1/documentation/api/latest/index.html).

Let's install it:

```
pip3 install boto3
```

## Add Image Creation to View

First we need to find the view that handles the creation of a Person in the DB.

This is the **post( )** method inside of the **People** class based view.

```py
def post(self, request):
  # insert code here that will intercept the request data before it goes to postgres
    person = PersonSerializer(data=request.data)
    if person.is_valid():
      person.save()
      return Response(person.data, status=status.HTTP_201_CREATED)
    else:
      return Response(person.errors, status=status.HTTP_400_BAD_REQUEST)
```

Currently the form on the frontend accepts a string in an input field for **image URL**. This will be refactored to allow for a **file upload** instead.

[MDN: Read more on Input Type "File"](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/input/file)

When the the request is received on the backend, the form data along with our file must be intercepted before being saved to postgres. We need to store the file contents in our S3 bucket and generate a URL before we save it and the rest of the data to the database.

First, we need to import more things in `views.py`:

1. The `boto3` library
1. Python's `uuid` utility that will help us generate random strings

```py
# add at the top below other dependencies
import uuid
import boto3
```

### Determine the correct AWS Service Endpoint

[AWS Regions and Endpoints reference](https://docs.aws.amazon.com/general/latest/gr/rande.html)

![s3 signup](./assets/region.png)

<br>

AWS has different endpoints (URLs) dependent upon the service (S3 in our case) and geographic region.

The [S3 docs](https://docs.aws.amazon.com/general/latest/gr/s3.html) reference these endpoints for the regions in the U.S.:

- `https://s3.us-east-1.amazonaws.com/` (N. Virginia)
- `https://s3.us-east-2.amazonaws.com/` (Ohio)
- `https://s3.us-west-1.amazonaws.com/` (N. California)
- `https://s3.us-west-2.amazonaws.com/` (Oregon)

Be sure to choose the endpoint for the region you used when creating your bucket add the endpoint's URL to the `.env` file, for example:

```
AWS_ACCESS_KEY_ID=<paste your Access key ID>
AWS_SECRET_ACCESS_KEY=<paste your Secret access key>
S3_BUCKET=<your bucket name>
S3_BASE_URL=https://s3.us-west-2.amazonaws.com/
```

> 👀 Be sure to include `https://` in front of the endpoint and the trailing slash (`/`) at the end.

### Each File in S3 Must Have a Unique URL

Each file uploaded to S3 must have a unique URL.

We'll be "building" this unique URL using:

- The `S3_BASE_URL`
- The `S3_BUCKET` and...
- A randomly generated string known as the "key"

It's this unique URL we'll be saving in a `Photo` object's `url` attribute.

### Upload in View

Finally, this is where the magic happens, we'll review the code as we type it in:

```python
# Add this import to the top to access the env vars
import os

...
```

```py
  def post(self, request):
    # "image" will be the "name" attribute on the <input type="file">
    photo_file = request.FILES.get('image', None)

    if photo_file:
        s3 = boto3.client('s3')
        # need a unique "key" for S3 / needs image file extension too
        key = uuid.uuid4().hex[:6] + photo_file.name[photo_file.name.rfind('.'):]
        # just in case something goes wrong
        try:
            bucket = os.environ['S3_BUCKET']
            # send it off to S3
            s3.upload_fileobj(photo_file, bucket, key)
            # build the full url string to save in our DB
            newUrl = f"{os.environ['S3_BASE_URL']}{bucket}/{key}"
            # get the data obj from our request
            data = request.data
            # add an image key to data obj for our new s3 image url
            data["image"] = newUrl
            # save our person data
            person = PersonSerializer(data=data)
            if person.is_valid():
              person.save()
              return Response(person.data, status=status.HTTP_201_CREATED)
            else:
              return Response(person.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            print('An error occurred uploading file to S3')
            print(e)
    return Response("Upload Error", status=status.HTTP_400_BAD_REQUEST)
```

Code like...

```python
key = uuid.uuid4().hex[:6] + photo_file.name[photo_file.name.rfind('.'):]
```

...is a great line of code to examine in smaller pieces within the debugger if it seems overwhelming.

**Test with Postman if you want.**

<br>

## Update The UI

In your frontend, navigate to the form in `Index.jsx` and find the image input:

```jsx
<form onSubmit={handleSubmit}>
  <input
    type="text"
    name="name"
    placeholder="name"
    value={form.name}
    onChange={handleChange}
  />
  <input // <- find the image input
    type="text"
    name="image"
    value={form.image}
    onChange={handleFileChange}
  />
  <input
    type="text"
    name="title"
    placeholder="title"
    value={form.title}
    onChange={handleChange}
  />
  <input type="submit" value="Submit" />
</form>
```

We need to change the type from **text** to a **file**.

```jsx
<input
  type="file" // <- change to file
  name="image"
  value={form.image}
  onChange={handleChange}
/>
```

We will also need to add a slightly different handler function for the `onChange` event.

The current onchange uses the format:

```jsx
const handleChange = (evt) => {
  setForm({
    ...form,
    [evt.target.name]: evt.target.value, // <- e.target.value wont work here
  });
};
```

Create a new handle change function below it:

```jsx
const handleFileChange = (evt) => {
  setForm({
    ...form,
    [evt.target.name]: evt.target.files[0], // <- we need to reference the file
  });
};
```

Now add the new **handleFileChange** function:

```jsx
<input
  type="file"
  name="image"
  onChange={handleFileChange} // <- update
/>
```

Now lets make one last update to our **POST** request in `Main.jsx`:

```jsx
// CREATE
const createPeople = async (person) => {
  let formData = new FormData(); // <- Formats our form data correctly to send to server
  formData.append("name", person.name); // <- Manually add our form fields
  formData.append("image", person.image, person.image.name);
  formData.append("title", person.title);
  await fetch(URL, {
    method: "POST",
    body: formData,
  });
  getPeople();
};
```

You will need to make the same updates to the **PUT** request and **Edit Form**  in `Show.jsx`.

In `Main.jsx`:

```jsx
// UPDATE
const updatePeople = async (person, id) => {
  let formData = new FormData();
  formData.append("name", person.name);
  formData.append("image", person.image, person.image.name);
  formData.append("title", person.title);
  await fetch(URL + id, {
    method: "PUT",
    body: formData,
  });
  getPeople();
};
```

In `Show.jsx`:

```jsx
const handleFileChange = (evt) => {
    setEditForm({
      ...editForm,
      [evt.target.name]: evt.target.files[0],
    });
  };


...

<input 
  type="file" 
  name="image" 
  onChange={handleFileChange} 
/>
```


Test your new frontend image upload!
